/**
 * 
 */
function lsetActive(idName){
	var a = document.getElementById(idName);
	a.className += "active";
}